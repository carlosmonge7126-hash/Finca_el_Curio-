# Finca El Curio — Correcciones aplicadas

## Bugs encontrados y corregidos

1. **`api/reservar.mjs`**: el import estaba roto (`from "https://esm.sh"`, sin
   paquete). Node/Vercel no puede importar así. Se corrigió a
   `import { createClient } from '@supabase/supabase-js'`.
2. **`package.json`**: faltaba la dependencia `@supabase/supabase-js`
   (todas las funciones en `/api` la usan, pero no estaba instalada — el
   deploy habría fallado). Se agregó, junto con `"type": "module"` para que
   Vercel interprete correctamente el `import` de los archivos `.js`. Se
   quitó `pg`, que no se usa en ningún archivo del proyecto.
3. **`index.html` nunca cargaba el SDK de Supabase**: no existía ningún
   `<script src="...supabase...">` en el HTML, por lo que
   `typeof supabase` siempre era `undefined` y la app nunca llegaba a
   conectarse (solo mostraba el warning en consola). Se agregó el script
   del SDK antes del bloque de código principal.
4. **Doble envío de reservas**: el botón "Confirmar Reserva" tenía dos
   manejadores a la vez (`onclick="procesarReserva()"` en el HTML +
   `addEventListener('click', hacerReserva)` en JS), así que cada clic
   ejecutaba dos flujos distintos y podía duplicar la reserva. Se eliminó
   la función `hacerReserva()` (guardaba solo en localStorage, no en
   Supabase) y se dejó únicamente `procesarReserva()`.
5. **Las reservas no se guardaban en Supabase**: `procesarReserva()` solo
   mandaba los datos a Google Sheets y a `localStorage`, nunca al backend.
   Se agregó `enviarReservaSupabase()`, que llama a `/api/reservar` (ya
   existía la función serverless, pero nada la invocaba).
6. Se eliminó `Completo.pnj`, un archivo de texto vacío sin ningún uso.

## Lo que necesitas configurar tú (no lo puedo rellenar por ti)

### 1. Variables de entorno en Vercel (Project Settings → Environment Variables)
- `NEXT_PUBLIC_SUPABASE_URL` → URL de tu proyecto (Supabase → Settings → API)
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` → tu clave "anon public"
- `SUPABASE_URL` → la misma URL de arriba
- `SUPABASE_SERVICE_ROLE_KEY` → tu clave "service_role" (secreta, nunca la
  pongas en el frontend)

### 2. Credenciales en el propio `index.html`
Busca estas líneas (cerca del final del `<script>`) y reemplázalas con tu
URL y anon key reales:

```js
const SUPABASE_URL = 'https://TU_PROYECTO_ID.supabase.co';
const SUPABASE_ANON_KEY = 'TU_ANON_KEY_AQUI';
```

### 3. Crear la tabla en Supabase
Corre el archivo `supabase_schema.sql` en el SQL Editor de tu proyecto
Supabase. Crea la tabla `reservas` con las columnas que ya usa el código
(`nombre`, `email`, `telefono`, `fecha`, `tour`, `horario`, `created_at`) y
las políticas de seguridad (RLS) necesarias.

### 4. Habilitar Auth por email en Supabase
`api/login.js` y `api/register.js` usan `supabase.auth.signUp` /
`signInWithPassword`. Confirma en Supabase → Authentication → Providers
que el proveedor "Email" esté activo.

## Importante: el registro/login de clientes y el panel de admin
`index.html` maneja clientes, plantas, padrinos y el panel de
administración **enteramente con `localStorage`** (no con Supabase),
aunque exista `api/login.js` y `api/register.js` — el frontend nunca los
llama. Esto significa que esos datos:
- solo existen en el navegador de cada usuario (no se comparten entre
  dispositivos),
- no tienen relación real con la tabla `reservas` de Supabase.

No toqué esa parte porque reescribirla implica diseñar tablas nuevas
(`clientes`, `plantas`, `padrinos`) y rehacer bastante lógica del panel de
admin — es un cambio grande. Si quieres, puedo hacerlo en un siguiente
paso; dime y seguimos por ahí.
